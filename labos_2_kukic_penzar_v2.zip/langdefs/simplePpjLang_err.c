int x = 3 &;
int y = 2;
